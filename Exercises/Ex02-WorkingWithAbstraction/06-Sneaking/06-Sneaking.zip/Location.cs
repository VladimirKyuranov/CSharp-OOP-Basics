﻿ public class Location
{
    public int Row { get; set; }
    public int Col { get; set; }
}