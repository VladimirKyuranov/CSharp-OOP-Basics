﻿using System;
using System.Collections.Generic;
using System.Text;

public enum SeasonMultiplier
{
    Autumn = 1,
    Spring,
    Winter,
    Summer
}

public enum Discount
{
    None = 0,
    SecondVisit = 10,
    VIP = 20
}